var ausmashToken = "0ea76df066ce329ecc88461b766f591f";
var smashGGKey = "03f15efa601074e28bd2d1833f740af4"